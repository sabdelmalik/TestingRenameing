The executable and DLLs in this folder were obtained from [CrossWire](https://www.crosswire.org/) publicly available [sword utilities]( https://www.crosswire.org/ftpmirror/pub/sword/utils/). 
